
a:
$$ (\frac{7}{8} )+ (\frac{ 0}{0}) = (\frac{7} { 8}) $$
<br>

b:
$$ (\frac{ 7}{ 8)} - (\frac{ 4}{ 3)} = (\frac{ 3}{ 5)} $$
<br>

c:
$$ \vec{a} = \sqrt{3² + 5²} = sqrt(9+25) = sqrt(34) = 5.83  $$
<br>

d:
$$ \vec{a} = (\frac{ 2}{ 5} ) $$
$$ \vec{b} = (\frac{-2}{ 2} ) $$
$$ \vec{a} + \vec{b} = (\frac{7}{0} )$$
<br>

e:
$$ \vec{b} = (\frac{3}{ 2}) $$
$$ \vec{b} = (\frac{5}{ 1}) $$
$$ \vec{b} = (\frac{-2}{ 6}) $$

1 && 5
$$ \vec{a} + \vec{b} = (\frac{3}{2} )+ (\frac{5}{1} )= (\frac{8}{3} )$$

2
$$ \vec{b} + \vec{c} = (\frac{5}{1} )+ (\frac{-2}{6}) = (\frac{3}{7} )$$

3 && 4
$$ \vec{a} + \vec{b} + \vec{c} =  (\frac{3}{2} )+ (\frac{5}{1} )+ (\frac{-2}{6}) = (\frac{6}{9} )= (\frac{ni}{ce)} $$

f:

$$ 5*cos(\pi /5) = 4.05 $$
$$ 5*sin(\pi /5) = 2.94 $$

g:

$$ \vec{F} = (\frac{4.05}{2.94}) $$


h:

$$ F = \sqrt( 4.05^2 + 2.94^2 ) = \sqrt( 8.64 + 16.40) = \sqrt(25.05) = 5$$

i:

$$ \vec{a} = (\frac{-4}{5}) $$
$$ \vec{b} = 5\vec{a} $$
$$ \vec{b} = 5*(\frac{-4}{5}) = (\frac{-20}{25})$$

j:

$$ \vec{a} = \sqrt(-4²+5²) = \sqrt(-16 + 25) = \sqrt(9) = 3 $$

k:

$$ \vec{a} = \sqrt(-20²+25²) = \sqrt(-400 + 625) = \sqrt(225) = 15 $$ 

l:

$$ (\frac{1}{0}*)4 = (\frac{4}{0} )$$

m:

$$ (\frac{1}{3})*\frac{1}{2} = (\frac{0.5}{1.5})$$

n:

$$ \hat{a} = (\frac{x}{y}) / \sqrt(x² + y²) $$

$$ \hat{a} = (\frac{3}{0}) / \sqrt(3² + 0² ) = (\frac{3}{0}) / \sqrt(9) = (\frac{1}{0}) $$
$$ \hat{a} = (\frac{2}{2}) / \sqrt(2² + 2² ) = (\frac{2}{2}) / \sqrt(8) = (\frac{0.71}{0.71}) $$


o:

$$ \hat{a} = (\frac{3}{2}) / \sqrt(3² + 2² ) = (\frac{3}{2}) / \sqrt(13) = (\frac{0.83}{0.55}) $$

p:

$$ \hat{a} = (\frac{7}{-2}) / \sqrt(7² + -2² ) = (\frac{7}{-2}) / \sqrt(45) = (\frac{0.15}{-0.04}) $$

q:


$$  \vec{a} = (\frac{2}{3}) $$
$$  \vec{b} = (\frac{4}{6}) $$

$$ |\vec{a}| = \sqrt(2²+3²) = \sqrt(13) = 3.61 $$
$$ |\vec{b}| = \sqrt(4²+6²) = \sqrt(52) = 7.21  $$

$$ \vec{a}*\vec{b} = 3.61 * 7.21 * cos(0) = 26.03$$


r:

$$ \vec{a} = (\frac{2}{3}) $$
$$ \vec{b} = (\frac{-3}{2}) $$

$$ |\vec{a}| = \sqrt(2²+3²) = \sqrt(13) = 3.61 $$
$$ |\vec{b}| = \sqrt(-3²+2²) = \sqrt(5) = 2.24 $$

$$ \vec{a}*\vec{b} = 3.61 * 2.24 * cos(90) = -3.62 $$

The rest of the assignment is in python






